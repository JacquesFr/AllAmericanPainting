import React from 'react';

const Residential = () => {
    return (
        <div>
            <h1>Residential </h1>
            
        </div>
    );
};

export default Residential;