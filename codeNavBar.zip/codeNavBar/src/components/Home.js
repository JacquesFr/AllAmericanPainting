import React from 'react';

const Home = () => {
    return (
        <div>
            <h1>All American Painting - Home: slide show </h1>
            <h1>All American Painting - Home: Why us?</h1>
        </div>
    );
};

export default Home;