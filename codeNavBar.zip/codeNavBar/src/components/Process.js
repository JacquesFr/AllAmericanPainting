import React from 'react';

const Process = () => {
    return (
        <div>
            <h1>Process </h1>
            
        </div>
    );
};

export default Process;