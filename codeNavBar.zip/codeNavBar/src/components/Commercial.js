import React from 'react';

const Commercial = () => {
    return (
        <div>
            <h1>Commercial </h1>
            
        </div>
    );
};

export default Commercial;