import React, { Component } from 'react';

export const Home = () => (
    <div>
        <h1>Home</h1>
    </div>
)

export const Commercial = () => (
    <div>
        <h1>Commercial</h1>
    </div>
)

export const Residential = () => (
    <div>
        <h1>Residential</h1>
    </div>
)

export const Process = () => (
    <div>
        <h1>Process</h1>
    </div>
)

export const Contact = () => (
    <div>
        <h1>Contact Us</h1>
    </div>
)